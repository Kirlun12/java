package lb_one;

public class Koloda {
    
String[] koloda = new String[52];

    public void Sozdanie(){
        int count = 0;
        for (int i=0; i<4; i++){
           
        for (int j=0; j<13; j++){
            
            koloda[count] = new PlayingCard(PlayingCard.SUITS_LIST[i], PlayingCard.RANK_LIST[j]).toString();
            count++;
            
         
            
        }
       }
   }
    
    public void Meshaet(){
            String pervaya;
            String vtoraya;
            
            for(int i=0; i<1000; i++)
            {
                int num = ((int)(Math.random()*52));
                int num2 = ((int)(Math.random()*52));
                pervaya = koloda[num];
                vtoraya = koloda[num2];
                koloda[num] = vtoraya;
                koloda[num2] = pervaya;
                
            }
    }
            
            
    public void Razdacha(int colichestvo){
       int temp=0;
       System.out.println("===============================");
       for(int i=0; i<colichestvo; i++)
       {
           System.out.print("Игрок"+(i+1)+"\n");
           for(int j=0; j<5; j++)
           {
               System.out.print(" || " + koloda [temp] + " || , ");
               temp++;
           }

        System.out.println("\n");
        System.out.println("===============================================================================================");
               }
    }
              
}


