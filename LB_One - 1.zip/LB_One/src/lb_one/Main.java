package lb_one;
import java.util.Scanner;


public class Main {
  
   public static void main(String[] args) {  //блок основного кода программы
   
       Scanner input = new Scanner(System.in);
       int igroki = 0;
       int count = 0;
       
       
       
       while( igroki<1 ){
       System.out.print("Введите количество Игроков: ");
       igroki = input.nextInt();
       }
       System.out.println("Игроков " + igroki);
       
         Koloda someKoloda = new Koloda();    
         someKoloda.Sozdanie(); 
         someKoloda.Meshaet();
         someKoloda.Razdacha(igroki);
         input.close();
         
   }
}